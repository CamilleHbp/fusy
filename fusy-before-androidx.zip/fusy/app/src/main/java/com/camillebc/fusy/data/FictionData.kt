package com.camillebc.fusy.data

data class FictionData (val title: String, val imageUrl: String?, val description: String)
