package com.camillebc.fusy.data

class FictionRepository {
}